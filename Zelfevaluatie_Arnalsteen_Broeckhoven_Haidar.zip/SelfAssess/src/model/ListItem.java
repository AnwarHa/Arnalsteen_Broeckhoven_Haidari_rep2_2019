package model;

public interface ListItem {
}
